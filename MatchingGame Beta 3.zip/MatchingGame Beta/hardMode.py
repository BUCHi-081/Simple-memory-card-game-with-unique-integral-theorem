import sys
import random
from pathlib import Path
from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QHBoxLayout, QVBoxLayout, QStackedLayout, QMessageBox, QLabel
from PySide6.QtCore import QTimer, Qt, QSize, QUrl
from PySide6.QtGui import QFont, QPixmap, QIcon, QPainter, QColor
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput 
from PySide6.QtMultimediaWidgets import QVideoWidget 
from PySide6.QtCore import QUrl, Signal

class CardButton(QPushButton):
    def __init__(self, value, row, col, game):
        super().__init__()
        self.value = value
        self.row = row
        self.col = col
        self.game = game
        self.is_flipped = False
        self.is_matched = False
        
        self.card_back_path = self.game.get_asset_path("assets_card_eazy/Card.png")
        self.card_front_path = self.game.get_asset_path(f"assets_card_hard/{self.value}.png")

        card_back_pixmap = QPixmap(self.card_back_path)
        card_front_pixmap = QPixmap(self.card_front_path)

        self.card_back_icon = QIcon(card_back_pixmap)
        self.card_front_icon = QIcon(card_front_pixmap)
        
        self.card_back_glow_icon = QIcon(self.game.create_glow_pixmap(card_back_pixmap))
        self.card_front_glow_icon = QIcon(self.game.create_glow_pixmap(card_front_pixmap))

        self.setIcon(self.card_back_icon) 
        self.setIconSize(QSize(109, 164))
        self.setFixedSize(self.iconSize())
        self.setStyleSheet("QPushButton { border: none; background-color: transparent; }")

    def flip(self):
        if self.is_flipped:
            self.setIcon(self.card_back_icon)
            self.is_flipped = False
        else:
            self.setIcon(self.card_front_icon)
            self.is_flipped = True

    def enterEvent(self, event):
        if not self.is_matched:
            icon_to_set = self.card_front_glow_icon if self.is_flipped else self.card_back_glow_icon
            self.setIcon(icon_to_set)
        super().enterEvent(event)

    def leaveEvent(self, event):
        if not self.is_matched:
            icon_to_set = self.card_front_icon if self.is_flipped else self.card_back_icon
            self.setIcon(icon_to_set)
        super().leaveEvent(event)

class MemoryGame(QWidget):
    def __init__(self, main_menu=None, window_size=None):
        super().__init__()
        self.setWindowTitle("Memory Game - Hard")

        self.window_size = window_size
        self.main_menu = main_menu

        self.script_dir = Path(__file__).parent
        self.assets_dir = self.script_dir / "assets"

     

        self.player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.player.setAudioOutput(self.audio_output)
        self.player.mediaStatusChanged.connect(self._handle_end_video_finished)

        game_container = self.setup_ui()

        self.setFixedSize(game_container.size())

        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(game_container)
        self.setLayout(main_layout)

        self.start_new_game()

    def get_asset_path(self, filename):
        if 'assets' in filename:
            return str(self.script_dir / filename)
        return str(self.assets_dir / filename) 

    def create_glow_pixmap(self, pixmap):
        glow = QPixmap(pixmap.size())
        glow.fill(Qt.transparent)
        qp = QPainter(glow)
        qp.drawPixmap(0, 0, pixmap)
        qp.setCompositionMode(QPainter.CompositionMode_SourceAtop)
        qp.fillRect(glow.rect(), QColor(255, 255, 200, 80))
        qp.end()
        return glow

    def setup_bg_and_margins(self):

        pix = QPixmap(self.get_asset_path("Background.png"))
        if self.window_size:
            target_size = self.window_size
        else:
            target_size = QSize(1408, 792) # Ukuran default untuk testing
        display_pix = pix.scaled(target_size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        return display_pix

    def setup_ui(self):

        game_container = QWidget()

        display_pix = self.setup_bg_and_margins()
        game_container.setFixedSize(display_pix.size())

        bg_label = QLabel()
        bg_label.setPixmap(display_pix)

        self.game_page = QWidget()
        self.game_page.setAttribute(Qt.WA_TranslucentBackground)
        container_layout = QVBoxLayout(self.game_page)
        container_layout.setContentsMargins(3, 0, 0, 0)
        container_layout.setSpacing(0)
        container_layout.addSpacing(125)
        title_label = QLabel()
        title_pixmap = QPixmap(self.get_asset_path("Bangbo.png"))
        max_title_height = int(display_pix.height() * 0.25)
        scaled_pixmap = title_pixmap.scaledToHeight(max_title_height, Qt.SmoothTransformation)
        title_label.setPixmap(scaled_pixmap)
        title_label.setAlignment(Qt.AlignCenter)
        container_layout.addWidget(title_label)
        container_layout.addSpacing(20)
        card_area_layout = QHBoxLayout()
        card_area_layout.setContentsMargins(0,0,0,0)
        card_area_layout.addSpacing(20)
        self.card_container = QWidget()
        card_area_layout.addWidget(self.card_container)
        container_layout.addLayout(card_area_layout)
        container_layout.addStretch()

        self.video_layer = QVideoWidget()
        self.player.setVideoOutput(self.video_layer)

        self.stacked_layout = QStackedLayout(game_container)
        self.stacked_layout.setStackingMode(QStackedLayout.StackAll)
        self.stacked_layout.addWidget(bg_label)        
        self.stacked_layout.addWidget(self.game_page)  
        self.stacked_layout.addWidget(self.video_layer)

        self.stacked_layout.setCurrentWidget(self.game_page)
        self.back_button = QPushButton("X", self.game_page)
        self.back_button.setFixedSize(50, 25)
        self.back_button.move(40, 10)  
        self.back_button.setStyleSheet("""
            QPushButton {
            background-color: rgba(230, 0, 0, 255);
            color: white;
            border-radius: 10px;
            font-size: 14px;
            }
            QPushButton:hover {
            background-color: rgba(255, 255, 255, 200);
            color: black;
            }
        """)
        self.back_button.hide()
        self.back_button.clicked.connect(self.back_to_menu)
        font = QFont("Arial", 14, QFont.Bold)
        self.back_button.setFont(font)

        self.stacked_layout.setCurrentWidget(self.game_page)
        self.video_layer.hide() 

        return game_container
    def back_to_menu(self):
        self.close()
        if self.main_menu:
            self.main_menu.show()

    def start_new_game(self):
        if hasattr(self, 'cards'):
            for card in self.cards:
                card.setParent(None)
                card.deleteLater()

        self.matched_pairs_count = 0
        self.flipped_cards = []
        self.is_checking = False
        self.cards = []

        base_symbols = ['a', 'b', 'c', 'd', 'f', 'h'] 
        symbols = []
        for base in base_symbols:
            symbols.extend([base, f"{base}Y"])
        random.shuffle(symbols)

        self.total_pairs = len(symbols) // 2
        
        rows, cols = 3, 4
        card_width, card_height = 109, 164
        
        horizontal_step = card_width + 5
        vertical_step = card_height - 40

        container_width = (cols - 1) * horizontal_step + card_width
        container_height = (rows - 1) * vertical_step + card_height
        self.card_container.setFixedSize(container_width, container_height)

        for row in range(rows):
            for col in range(cols):
                symbol = symbols.pop()
                card = CardButton(symbol, row, col, self)
                card.setParent(self.card_container)
                card.clicked.connect(lambda checked, c=card: self.card_clicked(c))
                card.move(col * horizontal_step, row * vertical_step)
                card.show()
                self.cards.append(card)

    def card_clicked(self, card):
        if card.is_matched or card in self.flipped_cards or self.is_checking:
            return

        card.flip()
        self.flipped_cards.append(card)

        if len(self.flipped_cards) == 2:
            self.is_checking = True
            self.check_match()

    def check_match(self):
        card1, card2 = self.flipped_cards

        val1, val2 = card1.value, card2.value
        is_pair = False
        if  val1[:-1] == val2:
            is_pair = True
        elif val2[:-1] == val1:
            is_pair = True

        if is_pair:
            card1.is_matched = True
            card2.is_matched = True
            
            card1.setEnabled(False)
            card2.setEnabled(False)
            
            self.matched_pairs_count += 1
            self.flipped_cards = []
            self.is_checking = False
            
            

            if self.matched_pairs_count == self.total_pairs:
                self.show_win_message()
        else:
            QTimer.singleShot(1000, self.reset_cards)

    def reset_cards(self):
        for card in self.flipped_cards:
            card.flip()
        self.flipped_cards = []
        self.is_checking = False

    def show_win_message(self):
        video_path = self.get_asset_path("end.mp4")
        if self.main_menu and hasattr(self.main_menu, 'bgm_audio_output'):
            self.main_menu.bgm_audio_output.setVolume(0.1)

        self.player.setSource(QUrl.fromLocalFile(video_path))
        self.stacked_layout.setCurrentWidget(self.video_layer)
        self.video_layer.show()
        self.player.play()

    def _handle_end_video_finished(self, status):
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.player.stop()
            self.video_layer.hide()
            self.fade_in_bgm()

    def fade_in_bgm(self):
        if not (self.main_menu and hasattr(self.main_menu, 'bgm_audio_output')):
            return

        self.fade_timer = QTimer(self)
        self.current_volume = 0.1
        
        self.volume_step = 0.0225

        def update_volume():
            self.current_volume += self.volume_step
            if self.current_volume >= 1.0:
                self.main_menu.bgm_audio_output.setVolume(1.0)
                self.fade_timer.stop()
            else:
                self.main_menu.bgm_audio_output.setVolume(self.current_volume)
        
        self.fade_timer.timeout.connect(update_volume)
        self.fade_timer.start(100)

    def closeEvent(self, event):
        if self.main_menu:
            self.main_menu.show()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    game_window = MemoryGame()
    game_window.show()
    sys.exit(app.exec())
