import sys
import random
from pathlib import Path
from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QHBoxLayout, QVBoxLayout, QStackedLayout, QMessageBox, QLabel
from PySide6.QtCore import QTimer, Qt, QSize, QUrl
from PySide6.QtGui import QFont, QPixmap, QIcon, QPainter, QColor
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput 
from PySide6.QtMultimediaWidgets import QVideoWidget 
from PySide6.QtCore import QUrl, Signal

class HomeScreen(QWidget):
    def __init__(self, main_menu=None):
        super().__init__()
        self.main_menu = main_menu
        self.script_dir = Path(__file__).parent
        self.assets_dir = self.script_dir / "assets"
        self.button_scale = 0.84
        self.scale_factor = 1
        self.setWindowTitle("Memory Game") 

      
        self.menu_widget = self.setup_menu_ui()

       
        self.setFixedSize(self.menu_widget.size())

      
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.addWidget(self.menu_widget) 
        self.setLayout(main_layout)

       
       

    def get_asset_path(self, filename):
        return str(self.assets_dir / filename)

    def find_bbox(self, img):
        """Find non-transparent bounding box in QImage"""
        w, h = img.width(), img.height()
        minx, miny, maxx, maxy = w, h, 0, 0
        for y in range(h):
            for x in range(w):
                if img.pixelColor(x, y).alpha() > 0:
                    minx, maxx = min(minx, x), max(maxx, x)
                    miny, maxy = min(miny, y), max(maxy, y)
        return (minx, miny, maxx, maxy) if maxx > 0 else None

    def detect_left_margin(self, display_pix):
        """Auto-detect left white strip and return margin"""
        try:
            img = display_pix.toImage()
            w_img, h_img = img.width(), img.height()
            white_cols = [x for x in range(min(int(w_img * 0.25), w_img))
                         if sum(1 for y in range(h_img) 
                               if img.pixelColor(x, y).alpha() > 0 and 
                               all(img.pixelColor(x, y).getRgb()[i] > 230 for i in range(3)))
                         / max(1, h_img) > 0.05]
            if white_cols:
                segs = []
                start = white_cols[0]
                for x in white_cols[1:] + [white_cols[-1] + 2]:
                    if x != white_cols[white_cols.index(x) - 1] + 1 if x in white_cols else True:
                        if segs or start == white_cols[0]:
                            segs.append((start, white_cols[white_cols.index(x) - 1] if x in white_cols else x - 1))
                        start = x
                seg = max(segs, key=lambda s: s[1] - s[0]) if segs else (0, 0)
                return max(8, seg[1] + 8) if seg[1] > 0 else 8
        except:
            pass
        return 8

    def setup_bg_and_margins(self):
        
        pix = QPixmap(self.get_asset_path("credit.png"))

        max_w = int(1408 * self.scale_factor)
        max_h = int(792 * self.scale_factor)
        
        display_pix = pix.scaled(max_w, max_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        
        max_button_height = min(300, max(80, int(display_pix.height() * 0.22)))
        top_margin = int(display_pix.height() * 0.06) + 20
        left_margin = self.detect_left_margin(display_pix)
        
        return display_pix, max_button_height, top_margin, left_margin
    def setup_menu_ui(self):
        """Membangun seluruh UI menu dan mengembalikannya sebagai satu widget."""
        menu_container = QWidget()
        
        display_pix, self.max_button_height, self.top_margin, self.left_margin = self.setup_bg_and_margins()
        menu_container.setFixedSize(display_pix.size())

        
        bg_label = QLabel()
        bg_label.setPixmap(display_pix)
        
        
        button_widget = QWidget()
        button_widget.setAttribute(Qt.WA_TranslucentBackground)
        button_widget.setStyleSheet("background-color: transparent;") 
        button_layout = QVBoxLayout(button_widget)
        button_layout.setContentsMargins(self.left_margin, self.top_margin, 0, 0)
        button_layout.addStretch()

        button_col = QVBoxLayout()
        button_col.setAlignment(Qt.AlignHCenter)
        button_col.setSpacing(20)
        stacked_menu_layout = QStackedLayout(menu_container)
        stacked_menu_layout.setStackingMode(QStackedLayout.StackAll)
        stacked_menu_layout.setContentsMargins(0, 0, 0, 0)
        stacked_menu_layout.addWidget(bg_label)      # Lapisan paling belakang
        stacked_menu_layout.addWidget(button_widget) # Lapisan paling depan
        bg_label.lower() # Pastikan label latar belakang berada di lapisan paling bawah
        menu_container.setLayout(stacked_menu_layout)
        
        self.back_button = QPushButton("X", button_widget)
        self.back_button.setFixedSize(45, 36)
        self.back_button.move(100, 140)  
        self.back_button.setStyleSheet("""
            QPushButton {
            background-color: rgba(230, 0, 0, 160);
            color: white;
            border-radius: 10px;
            font-size: 40px;
            }
            QPushButton:hover {
            background-color: rgba(255, 255, 255, 200);
            color: black;
            }
        """)
        #self.back_button.hide()
        self.back_button.clicked.connect(self.back_to_menu)
        font = QFont("Arial", 14, QFont.Bold)
        self.back_button.setFont(font)
        return menu_container
     
    def back_to_menu(self):
        self.close()
        if self.main_menu:
            self.main_menu.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = HomeScreen()
    main_window.show()
    sys.exit(app.exec())