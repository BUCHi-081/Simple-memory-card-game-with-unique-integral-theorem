from PySide6.QtWidgets import QApplication, QWidget, QLabel, QToolButton, QVBoxLayout, QStackedLayout, QPushButton, QGraphicsBlurEffect
from PySide6.QtGui import QPixmap, QIcon, QImage, QPainter, QColor, QFont
from PySide6.QtCore import Qt, QSize, QTimer, QUrl
from pathlib import Path
from PySide6.QtMultimedia import QMediaPlayer, QAudioOutput
from PySide6.QtMultimediaWidgets import QVideoWidget
import sys
from eazyMode import MemoryGame as EasyGame
from normalMode import MemoryGame as NormalGame
from hardMode import MemoryGame as HardGame

class HomeScreen(QWidget):
    def __init__(self):
        super().__init__()
        self.script_dir = Path(__file__).parent
        self.assets_dir = self.script_dir / "assets"
        self.button_scale = 0.84
        self.scale_factor = 0.75
        self.setWindowTitle("Memory Game") 

        self.menu_widget = self.setup_menu_ui()
        self.credit_widget = self.setup_credit_ui()
        self.video_widget = QVideoWidget()

        self.setFixedSize(self.menu_widget.size())
       
        self.stacked_layout = QStackedLayout(self)
        self.stacked_layout.setStackingMode(QStackedLayout.StackAll)
        self.stacked_layout.addWidget(self.video_widget)
        self.stacked_layout.addWidget(self.menu_widget)  
        self.stacked_layout.addWidget(self.credit_widget)
        self.setLayout(self.stacked_layout)

        self.menu_widget.hide()
        self.credit_widget.hide()
        
        self.setup_and_play_video()

    def get_asset_path(self, filename):
        return str(self.assets_dir / filename)

    def find_bbox(self, img):
        
        w, h = img.width(), img.height()
        minx, miny, maxx, maxy = w, h, 0, 0
        for y in range(h):
            for x in range(w):
                if img.pixelColor(x, y).alpha() > 0:
                    minx, maxx = min(minx, x), max(maxx, x)
                    miny, maxy = min(miny, y), max(maxy, y)
        return (minx, miny, maxx, maxy) 


    def setup_bg_and_margins(self):
        
        pix = QPixmap(self.get_asset_path("Background.png"))

        max_w = int(1408 * self.scale_factor)
        max_h = int(792 * self.scale_factor)
        
        display_pix = pix.scaled(max_w, max_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        
        max_button_height = min(300, max(80, int(display_pix.height() * 0.22)))
        top_margin = int(display_pix.height() * 0.06) + 20
        left_margin = 25
        
        return display_pix, max_button_height, top_margin, left_margin

    def create_glow_pixmap(self, pixmap):
        
        glow = QPixmap(pixmap.size())
        glow.fill(Qt.transparent)
        qp = QPainter(glow)
        qp.drawPixmap(0, 0, pixmap)
        qp.setCompositionMode(QPainter.CompositionMode_SourceAtop)
        qp.fillRect(glow.rect(), QColor(255, 255, 200, 60))
        qp.end()
        return glow

    def setup_button_interactions(self, btn, pixmap, padding):
        
        btn.orig_pixmap, btn.orig_icon, btn.orig_size = pixmap, QIcon(pixmap), pixmap.size()
        btn.glow_icon = QIcon(self.create_glow_pixmap(pixmap))
        
        def zoom_press():
            zoomed = btn.orig_pixmap.scaledToHeight(int(btn.orig_pixmap.height() * 1.08), Qt.SmoothTransformation)
            btn.setIcon(QIcon(zoomed))
            btn.setIconSize(zoomed.size())
            QTimer.singleShot(100, lambda: (btn.setIcon(btn.orig_icon), btn.setIconSize(btn.orig_size)))
        
        def on_enter(event):
            btn.setIcon(btn.glow_icon)
        def on_leave(event):
            btn.setIcon(btn.orig_icon)
        
        btn.pressed.connect(zoom_press)
        btn.enterEvent = on_enter
        btn.leaveEvent = on_leave

    def create_mode_button(self, icon_file, custom_scale=1.0):
        btn = QToolButton(self)
        icon_path = self.get_asset_path(icon_file)
        img = QImage(icon_path)
        
        
        bbox = self.find_bbox(img)
        if bbox:
            minx, miny, maxx, maxy = bbox
            bbox_w, bbox_h = maxx - minx + 1, maxy - miny + 1
            cropped = QPixmap(icon_path).copy(minx, miny, bbox_w, bbox_h)
            pixmap = cropped.scaledToHeight(int(self.max_button_height * self.button_scale * self.scale_factor * custom_scale), Qt.SmoothTransformation)
        
        padding = 10
        btn.setIcon(QIcon(pixmap))
        btn.setIconSize(pixmap.size())
        btn.setText("")
        btn.setToolButtonStyle(Qt.ToolButtonIconOnly)
        btn.setFixedSize(pixmap.width() + padding * 3, pixmap.height() + padding)
        btn.setStyleSheet("QToolButton { background-color: transparent; border: none; padding: 0px; margin: 5px; }")
        
        self.setup_button_interactions(btn, pixmap, padding)
        return btn

    def setup_credit_ui(self):
        credit_container = QWidget()
        pix = QPixmap(self.get_asset_path("credit.png"))
        max_w = int(1408 * self.scale_factor)
        max_h = int(792 * self.scale_factor)
        display_pix = pix.scaled(max_w, max_h, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        credit_container.setFixedSize(display_pix.size())
        
        bg_label = QLabel(credit_container)
        bg_label.setPixmap(display_pix)
        
        back_button = QPushButton("X", credit_container)
        back_button.setFixedSize(45, 36)
        back_button.move(100, 140)
        back_button.setStyleSheet("""
            QPushButton {
            background-color: rgba(230, 0, 0, 160);
            color: white;
            border-radius: 10px;
            font-size: 40px;
            }
            QPushButton:hover {
            background-color: rgba(255, 255, 255, 200);
            color: black;
            }
        """)
        back_button.clicked.connect(self.close_credit)
        font = QFont("Arial", 14, QFont.Bold)
        back_button.setFont(font)
        
        return credit_container

    def setup_menu_ui(self):
        
        menu_container = QWidget()
        
        display_pix, self.max_button_height, self.top_margin, self.left_margin = self.setup_bg_and_margins()
        menu_container.setFixedSize(display_pix.size())

        
        bg_label = QLabel()
        bg_label.setPixmap(display_pix)
        
        
        button_widget = QWidget()
        button_widget.setAttribute(Qt.WA_TranslucentBackground)

        button_layout = QVBoxLayout(button_widget)
        button_layout.setContentsMargins(self.left_margin, self.top_margin, 0, 0)
        button_layout.addStretch()

        button_col = QVBoxLayout()
        button_col.setAlignment(Qt.AlignHCenter)
        button_col.setSpacing(20)

       
        button_wise = self.create_mode_button("Wise.png")
        button_wise.clicked.connect(self.open_easy_mode) 
        button_col.addWidget(button_wise, alignment=Qt.AlignHCenter)

    
        button_belle = self.create_mode_button("Belle.png")
        button_belle.clicked.connect(self.open_normal_mode)
        button_col.addWidget(button_belle, alignment=Qt.AlignHCenter)

        button_bangbo = self.create_mode_button("Bangbo.png")
        button_bangbo.clicked.connect(self.open_hard_mode)
        button_col.addWidget(button_bangbo, alignment=Qt.AlignHCenter)

        button_credit = self.create_mode_button("butoncredit.png", custom_scale=0.5)
        button_credit.clicked.connect(self.open_credit)
        button_col.addWidget(button_credit, alignment=Qt.AlignHCenter)

        button_layout.addLayout(button_col)
        button_layout.addStretch()

       
        stacked_menu_layout = QStackedLayout(menu_container)
        stacked_menu_layout.setStackingMode(QStackedLayout.StackAll)
        stacked_menu_layout.setContentsMargins(0, 0, 0, 0)
        stacked_menu_layout.addWidget(bg_label)     
        stacked_menu_layout.addWidget(button_widget) 
        bg_label.lower()
        menu_container.setLayout(stacked_menu_layout)
        
        return menu_container

    def setup_and_play_video(self):
        
        self.player = QMediaPlayer()
        self.audio_output = QAudioOutput()
        self.player.setVideoOutput(self.video_widget)
        self.player.setAudioOutput(self.audio_output)

        video_path = str(self.assets_dir / "opening.mp4")

        self.player.mediaStatusChanged.connect(self.video_finished)
        self.player.setSource(QUrl.fromLocalFile(video_path))
        self.stacked_layout.setCurrentWidget(self.video_widget)      
        self.player.play()

    def video_finished(self, status):
        
        if status == QMediaPlayer.MediaStatus.EndOfMedia:
            self.show_menu()

    def show_menu(self):
        
        self.video_widget.hide()
        self.menu_widget.show()
        self.stacked_layout.setCurrentWidget(self.menu_widget)
        self.player.stop() 
        self.setup_and_play_bgm()
        
    def open_easy_mode(self):
        
        self.game_window = EasyGame(main_menu=self, window_size=self.size())
        self.game_window.show()
        self.hide()

    def open_normal_mode(self):
        
        self.game_window = NormalGame(main_menu=self, window_size=self.size())
        self.game_window.show()
        self.hide()

    def open_hard_mode(self):
        
        self.game_window = HardGame(main_menu=self, window_size=self.size())
        self.game_window.show()
        self.hide()
    
    def open_credit(self):
        self.credit_widget.show()
        self.stacked_layout.setCurrentWidget(self.credit_widget)

    def close_credit(self):
        self.menu_widget.setGraphicsEffect(None)
        self.credit_widget.hide()
        self.stacked_layout.setCurrentWidget(self.menu_widget)

    def setup_and_play_bgm(self):
        
        self.bgm_player = QMediaPlayer()
        self.bgm_audio_output = QAudioOutput()
        self.bgm_player.setAudioOutput(self.bgm_audio_output)

       
        bgm_path = self.get_asset_path("bgm.mp3")

        self.bgm_player.setSource(QUrl.fromLocalFile(bgm_path))
        self.bgm_player.setLoops(QMediaPlayer.Infinite)
        self.bgm_audio_output.setVolume(1)
        self.bgm_player.play()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = HomeScreen()
    main_window.show()
    sys.exit(app.exec())